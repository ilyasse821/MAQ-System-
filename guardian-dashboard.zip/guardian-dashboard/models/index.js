// هذه النماذج يجب أن تبقى مطابقة تماماً (نفس اسم الـ model، نفس بنية
const mongoose = require("mongoose");

const GuildConfigSchema = new mongoose.Schema(
  {
    guildId: { type: String, required: true, unique: true, index: true },
    logChannels: {
      moderation: String,
      messages: String,
      voice: String,
      joins: String,
      server: String,
      tickets: String,
      automod: String,
      commands: String,
      errors: String
    },
    staffRoles: {
      trusted: { type: [String], default: [] },
      staff: { type: [String], default: [] },
      moderator: { type: [String], default: [] },
      admin: { type: [String], default: [] }
    },
    automod: {
      enabled: { type: Boolean, default: true },
      antiSpam: {
        enabled: { type: Boolean, default: true },
        maxMessages: { type: Number, default: 6 },
        perSeconds: { type: Number, default: 7 },
        action: { type: String, enum: ["warn", "mute", "kick"], default: "mute" }
      },
      antiInvite: { enabled: { type: Boolean, default: true }, allowlist: { type: [String], default: [] } },
      antiLink: { enabled: { type: Boolean, default: false }, allowlist: { type: [String], default: [] } },
      antiMentionSpam: { enabled: { type: Boolean, default: true }, maxMentions: { type: Number, default: 6 } },
      antiRaid: {
        enabled: { type: Boolean, default: true },
        joinThreshold: { type: Number, default: 10 },
        perSeconds: { type: Number, default: 30 },
        minAccountAgeMinutes: { type: Number, default: 30 },
        action: { type: String, enum: ["kick", "ban", "lockdown_only"], default: "lockdown_only" }
      },
      antiMassAction: { enabled: { type: Boolean, default: true }, maxActionsPerMinute: { type: Number, default: 5 } },
      ignoredChannels: { type: [String], default: [] },
      ignoredRoles: { type: [String], default: [] }
    },
    tickets: {
      enabled: { type: Boolean, default: true },
      categoryChannelId: String,
      supportRoleIds: { type: [String], default: [] },
      maxOpenPerUser: { type: Number, default: 1 },
      categories: { type: [{ key: String, label: String, emoji: String }], default: [] }
    },
    moderationEscalation: {
      warnsBeforeMute: { type: Number, default: 3 },
      warnsBeforeKick: { type: Number, default: 5 },
      warnsBeforeBan: { type: Number, default: 7 }
    },
    lockdown: {
      active: { type: Boolean, default: false },
      activatedBy: String,
      activatedAt: Date
    }
  },
  { timestamps: true }
);
const GuildConfig = mongoose.model("GuildConfig", GuildConfigSchema);

const ModerationCaseSchema = new mongoose.Schema(
  {
    guildId: { type: String, required: true, index: true },
    caseId: Number,
    type: String,
    targetId: String,
    targetTag: String,
    moderatorId: String,
    moderatorTag: String,
    reason: String,
    active: { type: Boolean, default: true },
    duration: Number,
    expiresAt: Date
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);
const ModerationCase = mongoose.model("ModerationCase", ModerationCaseSchema);

const TicketSchema = new mongoose.Schema(
  {
    guildId: { type: String, required: true, index: true },
    ticketNumber: Number,
    channelId: String,
    category: String,
    ownerId: String,
    ownerTag: String,
    claimedBy: String,
    status: { type: String, enum: ["open", "claimed", "closed"], default: "open" },
    closedBy: String,
    closedReason: String,
    closedAt: Date
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);
const Ticket = mongoose.model("Ticket", TicketSchema);

const AuditEntrySchema = new mongoose.Schema(
  {
    guildId: { type: String, required: true, index: true },
    category: { type: String, required: true, index: true },
    action: String,
    executorId: String,
    executorTag: String,
    targetId: String,
    targetTag: String,
    channelId: String,
    channelName: String,
    reason: String,
    before: mongoose.Schema.Types.Mixed,
    after: mongoose.Schema.Types.Mixed,
    metadata: mongoose.Schema.Types.Mixed
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);
const AuditEntry = mongoose.model("AuditEntry", AuditEntrySchema);

// ---- كود PIN لدخول الداشبورد (مستقل تماماً عن بيانات البوت) ----
const DashboardAuthSchema = new mongoose.Schema(
  {
    key: { type: String, default: "singleton", unique: true },
    pinHash: { type: String, required: true },
    failedAttempts: { type: Number, default: 0 },
    lockedUntil: Date,
    updatedAt: { type: Date, default: Date.now }
  },
  { timestamps: false }
);
const DashboardAuth = mongoose.model("DashboardAuth", DashboardAuthSchema);

module.exports = { GuildConfig, ModerationCase, Ticket, AuditEntry, DashboardAuth };
