# Guardian Dashboard — لوحة تحكم بوت Guardian

مشروع Node/Express منفصل تماماً عن البوت (`index.js`)، لكنه يتصل **بنفس قاعدة MongoDB** فيقرأ ويكتب نفس البيانات التي يستخدمها البوت مباشرة — بدون أي مزامنة يدوية أو API وسيط بينهما.

## الإعداد (بالترتيب)

### 1. في Discord Developer Portal (نفس تطبيق البوت)
اذهب إلى https://discord.com/developers/applications → تطبيقك → OAuth2 → General، وأضف Redirect:
```
http://localhost:3000/auth/callback
```
(أو رابط النطاق الحقيقي عند النشر، بنفس القيمة الموجودة في `DISCORD_REDIRECT_URI`).

### 2. التثبيت
```bash
npm install
cp .env.example .env
```
عبّي في `.env`:
- `DISCORD_CLIENT_ID` و`DISCORD_CLIENT_SECRET` (من نفس صفحة OAuth2)
- `DISCORD_BOT_TOKEN` — **نفس** التوكن المستخدم في `index.js` تاع البوت (ضروري لجلب قوائم الرومات والرتب الحقيقية)
- `MONGODB_URI` — **نفس** القيمة بالضبط الموجودة في `.env` تاع البوت
- `SESSION_SECRET` — سلسلة عشوائية طويلة

### 3. التشغيل
```bash
npm start
```
افتح `http://localhost:3000`.

## صلاحيات البوت المطلوبة (لتعمل صفحات الإعدادات)
البوت يحتاج أن يكون داخل السيرفر بصلاحية **View Channels** و**Manage Roles** على الأقل حتى تُعرض قوائم الرومات/الرتب في نماذج الإعدادات (`/guilds/{id}/channels` و`/guilds/{id}/roles` عبر Bot Token).

## من يقدر يدخل لأي سيرفر؟
عند تسجيل الدخول، نجلب قائمة سيرفرات المستخدم من Discord (`GET /users/@me/guilds`) ونفلترها لمن يملك **Administrator** أو **Manage Server** فقط. مالكو البوت (`BOT_OWNER_IDS`) يتجاوزون هذا الفلتر لأغراض الصيانة الطارئة.

## ⚠️ ملاحظة صدق حول الاختبار

بنيت هذا الكود داخل بيئة بدون اتصال إنترنت (لا يمكنها تثبيت `npm install` فعلياً ولا تشغيل خادم حقيقي)، لذلك:
- تحققت من **صيغة (syntax) كل ملفات JavaScript** عبر `node --check` — كلها سليمة.
- تحققت من **توازن وسوم EJS** (`<%` مقابل `%>`) في كل صفحة يدوياً — كلها متوازنة.
- **لم أستطع تشغيل خادم حقيقي أو رندر فعلي للصفحات** لعدم توفر اتصال إنترنت لتثبيت الحزم في هذه الجلسة. رجاءً جرّب `npm install && npm start` عندك وأخبرني بأي خطأ تصادفه — سأصلحه فوراً بدل أن أدّعي أنه "مضمون 100%" بدون اختبار حقيقي.

## البنية
```
config/env.js          تحميل والتحقق من متغيرات البيئة
models/index.js         نفس نماذج قاعدة بيانات البوت بالضبط
services/discordApi.js  OAuth2 + طلبات بتوكن البوت (رومات/رتب)
middleware/auth.js       حراسة الجلسة والوصول لكل سيرفر
routes/auth.js           تسجيل الدخول/الخروج عبر Discord
routes/dashboard.js       كل صفحات العرض (GET)
routes/api.js            حفظ الإعدادات + تفعيل/إلغاء القفل الطارئ (POST)
views/                   قوالب EJS
public/css/style.css     التصميم الكامل (هوية Security Console)
```
