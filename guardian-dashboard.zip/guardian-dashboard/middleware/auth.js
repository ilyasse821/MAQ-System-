const { fetchBotGuilds } = require("../services/discordApi");

function ensureAuthenticated(req, res, next) {
  if (req.session?.authenticated) return next();
  req.session.returnTo = req.originalUrl;
  return res.redirect("/auth/login");
}

// يتحقق أن البوت فعلاً موجود في السيرفر المطلوب (يمنع الوصول لمعرف سيرفر عشوائي).
async function ensureGuildAccess(req, res, next) {
  try {
    const { guildId } = req.params;
    const guilds = await fetchBotGuilds();
    const found = guilds.some((g) => g.id === guildId);
    if (!found) {
      return res.status(403).render("error", { title: "الوصول مرفوض", message: "البوت غير موجود في هذا السيرفر." });
    }
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = { ensureAuthenticated, ensureGuildAccess };
