require("dotenv/config");

const REQUIRED = ["DISCORD_BOT_TOKEN", "MONGODB_URI", "SESSION_SECRET"];
for (const key of REQUIRED) {
  if (!process.env[key]) {
    console.error(`❌ متغير البيئة المطلوب مفقود: ${key}`);
    process.exit(1);
  }
}

module.exports = {
  botToken: process.env.DISCORD_BOT_TOKEN,
  mongoUri: process.env.MONGODB_URI,
  ownerIds: (process.env.BOT_OWNER_IDS || "").split(",").map((s) => s.trim()).filter(Boolean),
  sessionSecret: process.env.SESSION_SECRET,
  // كود PIN الابتدائي — يُستخدم فقط أول مرة لا يوجد فيها PIN مخزَّن في القاعدة،
  // بعدها يُدار بالكامل من صفحة "تغيير PIN" داخل الداشبورد.
  initialPin: process.env.DASHBOARD_PIN || null,
  port: Number(process.env.PORT || 3000),
  isProd: process.env.NODE_ENV === "production"
};
