const express = require("express");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const mongoose = require("mongoose");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("node:path");

const env = require("./config/env");
const authRoutes = require("./routes/auth");
const dashboardRoutes = require("./routes/dashboard");
const apiRoutes = require("./routes/api");

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(
  helmet({
    // نسمح بخطوط Google Fonts فقط، بقية السياسة الافتراضية الصارمة تبقى كما هي
    contentSecurityPolicy: {
      directives: {
        ...helmet.contentSecurityPolicy.getDefaultDirectives(),
        "style-src": ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        "font-src": ["'self'", "https://fonts.gstatic.com"]
      }
    }
  })
);
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.use(rateLimit({ windowMs: 60_000, max: 120 }));

async function start() {
  await mongoose.connect(env.mongoUri);
  console.log("✅ الداشبورد متصل بقاعدة البيانات");

  app.use(
    session({
      secret: env.sessionSecret,
      resave: false,
      saveUninitialized: false,
      store: MongoStore.create({ mongoUrl: env.mongoUri, collectionName: "dashboardSessions" }),
      cookie: { maxAge: 1000 * 60 * 60 * 24 * 7, secure: env.isProd, httpOnly: true, sameSite: "lax" }
    })
  );

  app.get("/", (req, res) => {
    if (req.session.authenticated) return res.redirect("/dashboard");
    res.redirect("/auth/login");
  });

  app.use("/auth", authRoutes);
  app.use("/dashboard", dashboardRoutes);
  app.use("/api/guilds", apiRoutes);

  app.use((req, res) => {
    res.status(404).render("error", { title: "الصفحة غير موجودة", message: "الرابط الذي فتحته غير موجود." });
  });

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error(err);
    res.status(500).render("error", { title: "خطأ في الخادم", message: "حدث خطأ غير متوقع. حاول لاحقاً." });
  });

  app.listen(env.port, () => console.log(`✅ الداشبورد يعمل على http://localhost:${env.port}`));
}

start().catch((err) => {
  console.error("❌ فشل تشغيل الداشبورد:", err);
  process.exit(1);
});
