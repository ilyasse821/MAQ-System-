const bcrypt = require("bcryptjs");
const { DashboardAuth } = require("../models");
const env = require("../config/env");

const MAX_ATTEMPTS = 5;
const LOCK_MINUTES = 15;

// يُنشئ سجل PIN الأول من DASHBOARD_PIN في .env إذا لم يوجد أي سجل بعد.
async function ensurePinSeeded() {
  const existing = await DashboardAuth.findOne({ key: "singleton" });
  if (existing) return existing;

  if (!env.initialPin) {
    throw new Error(
      "لا يوجد كود PIN مخزَّن بعد، ويجب ضبط DASHBOARD_PIN في .env عند أول تشغيل فقط (يُستخدم مرة واحدة للبذر، بعدها غيّره من صفحة تغيير PIN)."
    );
  }
  if (!/^\d{4,8}$/.test(env.initialPin)) {
    throw new Error("DASHBOARD_PIN يجب أن يكون أرقاماً فقط، بين 4 و8 خانات.");
  }

  const pinHash = await bcrypt.hash(env.initialPin, 12);
  return DashboardAuth.create({ key: "singleton", pinHash });
}

// يتحقق من كود PIN المُدخَل. يعيد { ok, locked, remainingAttempts }.
async function verifyPin(inputPin) {
  const auth = await ensurePinSeeded();

  if (auth.lockedUntil && auth.lockedUntil > new Date()) {
    const minutesLeft = Math.ceil((auth.lockedUntil - new Date()) / 60000);
    return { ok: false, locked: true, minutesLeft };
  }

  const match = await bcrypt.compare(String(inputPin), auth.pinHash);

  if (!match) {
    auth.failedAttempts += 1;
    if (auth.failedAttempts >= MAX_ATTEMPTS) {
      auth.lockedUntil = new Date(Date.now() + LOCK_MINUTES * 60000);
      auth.failedAttempts = 0;
    }
    await auth.save();
    return { ok: false, locked: false, remainingAttempts: Math.max(0, MAX_ATTEMPTS - auth.failedAttempts) };
  }

  auth.failedAttempts = 0;
  auth.lockedUntil = undefined;
  await auth.save();
  return { ok: true };
}

async function changePin(currentPin, newPin) {
  if (!/^\d{4,8}$/.test(newPin)) {
    return { ok: false, error: "الكود الجديد يجب أن يكون أرقاماً فقط، بين 4 و8 خانات." };
  }

  const check = await verifyPin(currentPin);
  if (!check.ok) {
    return { ok: false, error: check.locked ? `الحساب مقفل مؤقتاً، حاول بعد ${check.minutesLeft} دقيقة.` : "الكود الحالي غير صحيح." };
  }

  const pinHash = await bcrypt.hash(newPin, 12);
  await DashboardAuth.findOneAndUpdate({ key: "singleton" }, { pinHash, updatedAt: new Date() });
  return { ok: true };
}

module.exports = { ensurePinSeeded, verifyPin, changePin };
