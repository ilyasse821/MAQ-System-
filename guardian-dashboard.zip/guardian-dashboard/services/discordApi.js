const axios = require("axios");
const env = require("../config/env");

const DISCORD_API = "https://discord.com/api/v10";

async function botRequest(path) {
  const { data } = await axios.get(`${DISCORD_API}${path}`, {
    headers: { Authorization: `Bot ${env.botToken}` }
  });
  return data;
}

// كل السيرفرات التي يوجد فيها البوت — تُستخدم لملء قائمة اختيار السيرفر في الداشبورد.
async function fetchBotGuilds() {
  return botRequest("/users/@me/guilds");
}

async function fetchGuildChannels(guildId) {
  const channels = await botRequest(`/guilds/${guildId}/channels`);
  return channels.filter((c) => c.type === 0 || c.type === 4).sort((a, b) => a.position - b.position);
}

async function fetchGuildRoles(guildId) {
  const roles = await botRequest(`/guilds/${guildId}/roles`);
  return roles.filter((r) => r.name !== "@everyone").sort((a, b) => b.position - a.position);
}

async function fetchGuildInfo(guildId) {
  return botRequest(`/guilds/${guildId}?with_counts=true`);
}

module.exports = { fetchBotGuilds, fetchGuildChannels, fetchGuildRoles, fetchGuildInfo };
