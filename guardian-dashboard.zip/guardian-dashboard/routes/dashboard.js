const express = require("express");
const { ensureAuthenticated, ensureGuildAccess } = require("../middleware/auth");
const { GuildConfig, ModerationCase, Ticket, AuditEntry } = require("../models");
const { fetchGuildChannels, fetchGuildRoles, fetchGuildInfo, fetchBotGuilds } = require("../services/discordApi");

const router = express.Router();
router.use(ensureAuthenticated);

async function getConfig(guildId) {
  return GuildConfig.findOneAndUpdate({ guildId }, { $setOnInsert: { guildId } }, { upsert: true, new: true });
}

router.get("/", (req, res) => res.redirect("/dashboard"));

// ---- قائمة السيرفرات (مباشرة من توكن البوت - كل سيرفر موجود فيه البوت) ----
router.get("/dashboard", async (req, res, next) => {
  try {
    const guilds = await fetchBotGuilds();
    res.render("guilds", { guilds });
  } catch (err) {
    next(err);
  }
});

router.use("/dashboard/:guildId", ensureGuildAccess, async (req, res, next) => {
  try {
    res.locals.guildId = req.params.guildId;
    const [guildInfo, config] = await Promise.all([
      fetchGuildInfo(req.params.guildId).catch(() => null),
      getConfig(req.params.guildId)
    ]);
    res.locals.guildInfo = guildInfo;
    res.locals.lockdownActive = Boolean(config.lockdown && config.lockdown.active);
    next();
  } catch (err) {
    next(err);
  }
});

// ---- نظرة عامة ----
router.get("/dashboard/:guildId", async (req, res, next) => {
  try {
    const { guildId } = req.params;
    const config = await getConfig(guildId);
    const [openTickets, totalCases, recentEntries, todayCases] = await Promise.all([
      Ticket.countDocuments({ guildId, status: { $ne: "closed" } }),
      ModerationCase.countDocuments({ guildId }),
      AuditEntry.find({ guildId }).sort({ createdAt: -1 }).limit(8).lean(),
      ModerationCase.countDocuments({ guildId, createdAt: { $gte: new Date(Date.now() - 86400000) } })
    ]);

    res.render("overview", {
      
      guildId,
      guildInfo: res.locals.guildInfo,
      config,
      stats: { openTickets, totalCases, todayCases },
      recentEntries,
      active: "overview"
    });
  } catch (err) {
    next(err);
  }
});

// ---- إعدادات تشانلات اللوق ----
router.get("/dashboard/:guildId/logs-config", async (req, res, next) => {
  try {
    const { guildId } = req.params;
    const [config, channels] = await Promise.all([getConfig(guildId), fetchGuildChannels(guildId)]);
    res.render("logsConfig", {
      
      guildId,
      guildInfo: res.locals.guildInfo,
      config,
      channels,
      active: "logs-config",
      saved: req.query.saved
    });
  } catch (err) {
    next(err);
  }
});

// ---- إعدادات الرتب والصلاحيات ----
router.get("/dashboard/:guildId/roles", async (req, res, next) => {
  try {
    const { guildId } = req.params;
    const [config, roles] = await Promise.all([getConfig(guildId), fetchGuildRoles(guildId)]);
    res.render("rolesConfig", {
      
      guildId,
      guildInfo: res.locals.guildInfo,
      config,
      roles,
      active: "roles",
      saved: req.query.saved
    });
  } catch (err) {
    next(err);
  }
});

// ---- إعدادات الحماية التلقائية ----
router.get("/dashboard/:guildId/automod", async (req, res, next) => {
  try {
    const { guildId } = req.params;
    const config = await getConfig(guildId);
    res.render("automodConfig", {
      
      guildId,
      guildInfo: res.locals.guildInfo,
      config,
      active: "automod",
      saved: req.query.saved
    });
  } catch (err) {
    next(err);
  }
});

// ---- التذاكر ----
router.get("/dashboard/:guildId/tickets", async (req, res, next) => {
  try {
    const { guildId } = req.params;
    const status = req.query.status || "all";
    const filter = { guildId };
    if (status !== "all") filter.status = status;

    const tickets = await Ticket.find(filter).sort({ createdAt: -1 }).limit(100).lean();
    res.render("tickets", { guildId, guildInfo: res.locals.guildInfo, tickets, status, active: "tickets" });
  } catch (err) {
    next(err);
  }
});

// ---- الإجراءات الإدارية (Cases) ----
router.get("/dashboard/:guildId/cases", async (req, res, next) => {
  try {
    const { guildId } = req.params;
    const type = req.query.type || "all";
    const filter = { guildId };
    if (type !== "all") filter.type = type;

    const cases = await ModerationCase.find(filter).sort({ createdAt: -1 }).limit(100).lean();
    res.render("cases", { guildId, guildInfo: res.locals.guildInfo, cases, type, active: "cases" });
  } catch (err) {
    next(err);
  }
});

// ---- سجل اللوقات (Audit Log) مع فلاتر وتصفح ----
router.get("/dashboard/:guildId/audit-log", async (req, res, next) => {
  try {
    const { guildId } = req.params;
    const category = req.query.category || "all";
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const pageSize = 30;

    const filter = { guildId };
    if (category !== "all") filter.category = category;

    const [entries, total] = await Promise.all([
      AuditEntry.find(filter)
        .sort({ createdAt: -1 })
        .skip((page - 1) * pageSize)
        .limit(pageSize)
        .lean(),
      AuditEntry.countDocuments(filter)
    ]);

    res.render("auditLog", {
      
      guildId,
      guildInfo: res.locals.guildInfo,
      entries,
      category,
      page,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
      active: "audit-log"
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
