const express = require("express");
const rateLimit = require("express-rate-limit");
const { verifyPin, changePin } = require("../services/pinService");

const router = express.Router();

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 8, standardHeaders: true, legacyHeaders: false });

router.get("/login", (req, res) => {
  if (req.session.authenticated) return res.redirect("/dashboard");
  res.render("login", { error: null });
});

router.post("/login", loginLimiter, async (req, res, next) => {
  try {
    const { pin } = req.body;
    const result = await verifyPin(pin);
    if (!result.ok) {
      const error = result.locked
        ? `تم قفل الدخول مؤقتاً بسبب محاولات فاشلة متكررة. حاول بعد ${result.minutesLeft} دقيقة.`
        : `كود PIN غير صحيح. المحاولات المتبقية: ${result.remainingAttempts}.`;
      return res.status(401).render("login", { error });
    }
    req.session.authenticated = true;
    const returnTo = req.session.returnTo || "/dashboard";
    delete req.session.returnTo;
    res.redirect(returnTo);
  } catch (err) {
    next(err);
  }
});

router.post("/logout", (req, res) => req.session.destroy(() => res.redirect("/auth/login")));

router.get("/change-pin", (req, res) => {
  if (!req.session.authenticated) return res.redirect("/auth/login");
  res.render("changePin", { error: null, success: null });
});

router.post("/change-pin", async (req, res, next) => {
  try {
    if (!req.session.authenticated) return res.redirect("/auth/login");
    const { currentPin, newPin, confirmPin } = req.body;
    if (newPin !== confirmPin) {
      return res.status(400).render("changePin", { error: "الكود الجديد وتأكيده غير متطابقين.", success: null });
    }
    const result = await changePin(currentPin, newPin);
    if (!result.ok) return res.status(400).render("changePin", { error: result.error, success: null });
    res.render("changePin", { error: null, success: "✅ تم تغيير كود PIN بنجاح." });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
