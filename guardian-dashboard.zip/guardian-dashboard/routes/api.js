const express = require("express");
const { ensureAuthenticated, ensureGuildAccess } = require("../middleware/auth");
const { GuildConfig } = require("../models");

const router = express.Router();
router.use(ensureAuthenticated);
router.use("/:guildId", ensureGuildAccess);

const LOG_CHANNEL_KEYS = ["moderation", "messages", "voice", "joins", "server", "tickets", "automod", "commands", "errors"];

router.post("/:guildId/logs-config", async (req, res, next) => {
  try {
    const set = {};
    for (const key of LOG_CHANNEL_KEYS) {
      // قيمة فارغة تعني "بدون تشانل" — نحذف الحقل بدل تخزين سلسلة فارغة
      set[`logChannels.${key}`] = req.body[key] || undefined;
    }
    await GuildConfig.findOneAndUpdate({ guildId: req.params.guildId }, { $set: set }, { upsert: true });
    res.redirect(`/dashboard/${req.params.guildId}/logs-config?saved=1`);
  } catch (err) {
    next(err);
  }
});

router.post("/:guildId/roles", async (req, res, next) => {
  try {
    const toArray = (v) => (Array.isArray(v) ? v : v ? [v] : []);
    const set = {
      "staffRoles.trusted": toArray(req.body.trusted),
      "staffRoles.staff": toArray(req.body.staff),
      "staffRoles.moderator": toArray(req.body.moderator),
      "staffRoles.admin": toArray(req.body.admin)
    };
    await GuildConfig.findOneAndUpdate({ guildId: req.params.guildId }, { $set: set }, { upsert: true });
    res.redirect(`/dashboard/${req.params.guildId}/roles?saved=1`);
  } catch (err) {
    next(err);
  }
});

router.post("/:guildId/automod", async (req, res, next) => {
  try {
    const b = req.body;
    const set = {
      "automod.enabled": b.enabled === "on",
      "automod.antiSpam.enabled": b.antiSpamEnabled === "on",
      "automod.antiSpam.maxMessages": Number(b.maxMessages) || 6,
      "automod.antiSpam.perSeconds": Number(b.perSeconds) || 7,
      "automod.antiInvite.enabled": b.antiInviteEnabled === "on",
      "automod.antiLink.enabled": b.antiLinkEnabled === "on",
      "automod.antiMentionSpam.enabled": b.antiMentionEnabled === "on",
      "automod.antiMentionSpam.maxMentions": Number(b.maxMentions) || 6,
      "automod.antiRaid.enabled": b.antiRaidEnabled === "on",
      "automod.antiRaid.joinThreshold": Number(b.joinThreshold) || 10,
      "automod.antiRaid.perSeconds": Number(b.raidPerSeconds) || 30,
      "automod.antiRaid.action": b.raidAction || "lockdown_only",
      "moderationEscalation.warnsBeforeMute": Number(b.warnsBeforeMute) || 3,
      "moderationEscalation.warnsBeforeKick": Number(b.warnsBeforeKick) || 5,
      "moderationEscalation.warnsBeforeBan": Number(b.warnsBeforeBan) || 7
    };
    await GuildConfig.findOneAndUpdate({ guildId: req.params.guildId }, { $set: set }, { upsert: true });
    res.redirect(`/dashboard/${req.params.guildId}/automod?saved=1`);
  } catch (err) {
    next(err);
  }
});

// ---- تفعيل/إلغاء القفل الطارئ من الداشبورد مباشرة (نفس تأثير أمر /lockdown في البوت) ----
router.post("/:guildId/lockdown/:state", async (req, res, next) => {
  try {
    const { guildId, state } = req.params;
    const lock = state === "on";
    const axios = require("axios");
    const env = require("../config/env");

    const channels = await axios
      .get(`https://discord.com/api/v10/guilds/${guildId}/channels`, { headers: { Authorization: `Bot ${env.botToken}` } })
      .then((r) => r.data);

    const everyoneId = guildId; // في Discord، معرّف رتبة @everyone يساوي معرّف السيرفر نفسه
    await Promise.all(
      channels
        .filter((c) => c.type === 0)
        .map((c) =>
          axios
            .put(
              `https://discord.com/api/v10/channels/${c.id}/permissions/${everyoneId}`,
              { type: 0, deny: lock ? "2048" : "0", allow: lock ? "0" : "0" }, // 2048 = SEND_MESSAGES bit
              { headers: { Authorization: `Bot ${env.botToken}` } }
            )
            .catch(() => null)
        )
    );

    await GuildConfig.findOneAndUpdate(
      { guildId },
      lock
        ? { $set: { "lockdown.active": true, "lockdown.activatedBy": req.session.user.id, "lockdown.activatedAt": new Date() } }
        : { $set: { "lockdown.active": false } },
      { upsert: true }
    );

    res.redirect(`/dashboard/${guildId}?lockdown=${state}`);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
